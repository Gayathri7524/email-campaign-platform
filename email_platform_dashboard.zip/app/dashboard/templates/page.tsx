"use client"

import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Search, MoreHorizontal, Copy, Trash2, Edit, Eye, FileText, Star } from "lucide-react"
import { useState } from "react"

const templates = [
  {
    id: 1,
    name: "Welcome Email",
    description: "Greet new subscribers with a warm welcome message",
    category: "Onboarding",
    starred: true,
    lastEdited: "2 days ago",
  },
  {
    id: 2,
    name: "Newsletter Layout",
    description: "Clean and modern newsletter template",
    category: "Newsletter",
    starred: true,
    lastEdited: "1 week ago",
  },
  {
    id: 3,
    name: "Product Announcement",
    description: "Announce new features and product updates",
    category: "Product",
    starred: false,
    lastEdited: "3 days ago",
  },
  {
    id: 4,
    name: "Promotional Sale",
    description: "Eye-catching template for sales and promotions",
    category: "Marketing",
    starred: false,
    lastEdited: "5 days ago",
  },
  {
    id: 5,
    name: "Re-engagement",
    description: "Win back inactive subscribers",
    category: "Retention",
    starred: false,
    lastEdited: "1 week ago",
  },
  {
    id: 6,
    name: "Event Invitation",
    description: "Invite subscribers to webinars and events",
    category: "Events",
    starred: true,
    lastEdited: "4 days ago",
  },
]

const categoryColors: Record<string, string> = {
  Onboarding: "bg-primary/20 text-primary",
  Newsletter: "bg-chart-2/20 text-chart-2",
  Product: "bg-chart-3/20 text-chart-3",
  Marketing: "bg-chart-4/20 text-chart-4",
  Retention: "bg-chart-5/20 text-chart-5",
  Events: "bg-primary/20 text-primary",
}

export default function TemplatesPage() {
  const [searchQuery, setSearchQuery] = useState("")

  const filteredTemplates = templates.filter((template) =>
    template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    template.description.toLowerCase().includes(searchQuery.toLowerCase())
  )

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Templates"
        description="Manage and create email templates for your campaigns."
        action={{
          label: "New Template",
          onClick: () => {},
        }}
      />

      <div className="p-6 space-y-6">
        {/* Search */}
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-secondary border-border text-foreground placeholder:text-muted-foreground"
          />
        </div>

        {/* Template Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredTemplates.map((template) => (
            <Card key={template.id} className="border-border bg-card hover:border-primary/50 transition-colors group">
              <CardContent className="p-0">
                {/* Preview Area */}
                <div className="relative h-40 bg-secondary rounded-t-lg flex items-center justify-center">
                  <FileText className="h-12 w-12 text-muted-foreground" />
                  <div className="absolute inset-0 bg-background/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <Button size="sm" variant="secondary" className="bg-card border-border">
                      <Eye className="mr-2 h-4 w-4" />
                      Preview
                    </Button>
                    <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
                      <Edit className="mr-2 h-4 w-4" />
                      Edit
                    </Button>
                  </div>
                  {template.starred && (
                    <div className="absolute top-3 right-3">
                      <Star className="h-5 w-5 fill-chart-3 text-chart-3" />
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="p-4">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold text-card-foreground">{template.name}</h3>
                      <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                        {template.description}
                      </p>
                    </div>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground shrink-0">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="bg-popover border-border">
                        <DropdownMenuItem className="text-popover-foreground focus:bg-accent focus:text-accent-foreground">
                          <Edit className="mr-2 h-4 w-4" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-popover-foreground focus:bg-accent focus:text-accent-foreground">
                          <Copy className="mr-2 h-4 w-4" />
                          Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-popover-foreground focus:bg-accent focus:text-accent-foreground">
                          <Star className="mr-2 h-4 w-4" />
                          {template.starred ? "Unstar" : "Star"}
                        </DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive focus:bg-destructive focus:text-destructive-foreground">
                          <Trash2 className="mr-2 h-4 w-4" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>

                  <div className="mt-4 flex items-center justify-between">
                    <Badge className={`border-0 ${categoryColors[template.category] || "bg-secondary text-secondary-foreground"}`}>
                      {template.category}
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      Edited {template.lastEdited}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredTemplates.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="h-16 w-16 rounded-full bg-secondary flex items-center justify-center mb-4">
              <FileText className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground">No templates found</h3>
            <p className="text-muted-foreground mt-1">
              Try adjusting your search terms or create a new template
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
