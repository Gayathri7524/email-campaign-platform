"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ArrowLeft, Send, Save, Clock, Users, FileText, Sparkles } from "lucide-react"

export default function NewCampaignPage() {
  const router = useRouter()
  const [campaignName, setCampaignName] = useState("")
  const [subject, setSubject] = useState("")
  const [previewText, setPreviewText] = useState("")
  const [selectedList, setSelectedList] = useState("")
  const [emailContent, setEmailContent] = useState("")

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Create Campaign"
        description="Design and send your email campaign."
      />

      <div className="p-6">
        <Button
          variant="ghost"
          onClick={() => router.back()}
          className="mb-6 text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Campaigns
        </Button>

        <div className="grid gap-6 lg:grid-cols-3">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Campaign Details */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-card-foreground flex items-center gap-2">
                  <FileText className="h-5 w-5 text-primary" />
                  Campaign Details
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  Set up the basic information for your campaign
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name" className="text-card-foreground">Campaign Name</Label>
                  <Input
                    id="name"
                    placeholder="e.g., Summer Sale Announcement"
                    value={campaignName}
                    onChange={(e) => setCampaignName(e.target.value)}
                    className="bg-input border-border text-card-foreground placeholder:text-muted-foreground"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="subject" className="text-card-foreground">Subject Line</Label>
                  <Input
                    id="subject"
                    placeholder="e.g., Don't miss our biggest sale of the year!"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="bg-input border-border text-card-foreground placeholder:text-muted-foreground"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="preview" className="text-card-foreground">Preview Text</Label>
                  <Input
                    id="preview"
                    placeholder="Text that appears next to the subject in inbox"
                    value={previewText}
                    onChange={(e) => setPreviewText(e.target.value)}
                    className="bg-input border-border text-card-foreground placeholder:text-muted-foreground"
                  />
                </div>
              </CardContent>
            </Card>

            {/* Email Content */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-card-foreground flex items-center gap-2">
                  <Sparkles className="h-5 w-5 text-primary" />
                  Email Content
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  Write or design your email content
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="editor" className="w-full">
                  <TabsList className="bg-secondary mb-4">
                    <TabsTrigger value="editor" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                      Editor
                    </TabsTrigger>
                    <TabsTrigger value="html" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                      HTML
                    </TabsTrigger>
                    <TabsTrigger value="preview" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                      Preview
                    </TabsTrigger>
                  </TabsList>
                  <TabsContent value="editor" className="space-y-4">
                    <Textarea
                      placeholder="Write your email content here..."
                      value={emailContent}
                      onChange={(e) => setEmailContent(e.target.value)}
                      className="min-h-[300px] bg-input border-border text-card-foreground placeholder:text-muted-foreground resize-none"
                    />
                  </TabsContent>
                  <TabsContent value="html" className="space-y-4">
                    <Textarea
                      placeholder="<html>...</html>"
                      className="min-h-[300px] bg-input border-border text-card-foreground placeholder:text-muted-foreground resize-none font-mono text-sm"
                    />
                  </TabsContent>
                  <TabsContent value="preview" className="space-y-4">
                    <div className="min-h-[300px] rounded-lg border border-border bg-secondary p-6">
                      <div className="mx-auto max-w-md bg-card rounded-lg border border-border p-6 shadow-lg">
                        <h2 className="text-lg font-semibold text-card-foreground mb-4">
                          {subject || "Your subject line will appear here"}
                        </h2>
                        <p className="text-muted-foreground whitespace-pre-wrap">
                          {emailContent || "Your email content will appear here..."}
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Recipients */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-card-foreground flex items-center gap-2">
                  <Users className="h-5 w-5 text-primary" />
                  Recipients
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label className="text-card-foreground">Send To</Label>
                  <Select value={selectedList} onValueChange={setSelectedList}>
                    <SelectTrigger className="bg-input border-border text-card-foreground">
                      <SelectValue placeholder="Select a list" />
                    </SelectTrigger>
                    <SelectContent className="bg-popover border-border">
                      <SelectItem value="all">All Subscribers (24,521)</SelectItem>
                      <SelectItem value="newsletter">Newsletter (18,230)</SelectItem>
                      <SelectItem value="product">Product Updates (12,450)</SelectItem>
                      <SelectItem value="promotions">Promotions (8,120)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {selectedList && (
                  <div className="p-3 rounded-lg bg-secondary">
                    <p className="text-sm text-muted-foreground">
                      Estimated recipients: <span className="text-card-foreground font-medium">
                        {selectedList === "all" ? "24,521" :
                          selectedList === "newsletter" ? "18,230" :
                            selectedList === "product" ? "12,450" : "8,120"}
                      </span>
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Actions */}
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-card-foreground">Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90">
                  <Send className="mr-2 h-4 w-4" />
                  Send Now
                </Button>
                <Button variant="outline" className="w-full border-border bg-secondary text-foreground hover:bg-muted">
                  <Clock className="mr-2 h-4 w-4" />
                  Schedule
                </Button>
                <Button variant="ghost" className="w-full text-muted-foreground hover:text-foreground hover:bg-secondary">
                  <Save className="mr-2 h-4 w-4" />
                  Save as Draft
                </Button>
              </CardContent>
            </Card>

            {/* Tips */}
            <Card className="border-primary/30 bg-primary/5">
              <CardContent className="p-4">
                <h4 className="font-medium text-primary mb-2">Pro Tips</h4>
                <ul className="text-sm text-muted-foreground space-y-2">
                  <li>Keep subject lines under 50 characters</li>
                  <li>Use preview text to boost open rates</li>
                  <li>Test on multiple email clients</li>
                  <li>Send at optimal times (Tue-Thu, 10am)</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
