"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Search,
  Mail,
  MoreHorizontal,
  Eye,
  MousePointer,
  Copy,
  Trash2,
  Edit,
  Play,
  Pause,
  Calendar,
  Users,
} from "lucide-react"

const campaigns = [
  {
    id: 1,
    name: "Summer Sale Launch",
    subject: "Exclusive Summer Deals - Up to 50% Off!",
    status: "sent",
    recipients: 12500,
    opened: 4250,
    clicked: 890,
    sentAt: "Jul 15, 2024 at 10:00 AM",
  },
  {
    id: 2,
    name: "Weekly Newsletter #42",
    subject: "This Week in Tech: AI, Cloud, and More",
    status: "sent",
    recipients: 8200,
    opened: 3100,
    clicked: 456,
    sentAt: "Jul 12, 2024 at 9:00 AM",
  },
  {
    id: 3,
    name: "Product Update v2.0",
    subject: "Introducing Our Latest Features",
    status: "draft",
    recipients: 0,
    opened: 0,
    clicked: 0,
    sentAt: null,
  },
  {
    id: 4,
    name: "Welcome Series - Day 1",
    subject: "Welcome to MailFlow!",
    status: "scheduled",
    recipients: 0,
    opened: 0,
    clicked: 0,
    scheduledFor: "Jul 20, 2024 at 8:00 AM",
  },
  {
    id: 5,
    name: "Re-engagement Campaign",
    subject: "We Miss You! Come Back for 20% Off",
    status: "sent",
    recipients: 5400,
    opened: 1620,
    clicked: 324,
    sentAt: "Jul 8, 2024 at 2:00 PM",
  },
  {
    id: 6,
    name: "Black Friday Teaser",
    subject: "Mark Your Calendar: Black Friday Preview",
    status: "draft",
    recipients: 0,
    opened: 0,
    clicked: 0,
    sentAt: null,
  },
]

function getStatusBadge(status: string) {
  switch (status) {
    case "sent":
      return <Badge className="bg-primary/20 text-primary border-0">Sent</Badge>
    case "draft":
      return <Badge variant="secondary" className="bg-muted text-muted-foreground border-0">Draft</Badge>
    case "scheduled":
      return <Badge className="bg-chart-3/20 text-chart-3 border-0">Scheduled</Badge>
    case "sending":
      return <Badge className="bg-chart-2/20 text-chart-2 border-0">Sending</Badge>
    default:
      return null
  }
}

export default function CampaignsPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [activeTab, setActiveTab] = useState("all")

  const filteredCampaigns = campaigns.filter((campaign) => {
    const matchesSearch = campaign.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      campaign.subject.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesTab = activeTab === "all" || campaign.status === activeTab
    return matchesSearch && matchesTab
  })

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Campaigns"
        description="Create and manage your email campaigns."
        action={{
          label: "New Campaign",
          onClick: () => router.push("/dashboard/campaigns/new"),
        }}
      />

      <div className="p-6 space-y-6">
        {/* Tabs and Search */}
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full sm:w-auto">
            <TabsList className="bg-secondary">
              <TabsTrigger value="all" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                All
              </TabsTrigger>
              <TabsTrigger value="sent" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                Sent
              </TabsTrigger>
              <TabsTrigger value="scheduled" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                Scheduled
              </TabsTrigger>
              <TabsTrigger value="draft" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
                Drafts
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search campaigns..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-secondary border-border text-foreground placeholder:text-muted-foreground"
            />
          </div>
        </div>

        {/* Campaign Grid */}
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {filteredCampaigns.map((campaign) => (
            <Card key={campaign.id} className="border-border bg-card hover:border-primary/50 transition-colors">
              <CardContent className="p-5">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                      <Mail className="h-5 w-5 text-primary" />
                    </div>
                    <div className="min-w-0">
                      <h3 className="font-semibold text-card-foreground truncate">{campaign.name}</h3>
                      <p className="text-sm text-muted-foreground truncate">{campaign.subject}</p>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground shrink-0">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-popover border-border">
                      <DropdownMenuItem className="text-popover-foreground focus:bg-accent focus:text-accent-foreground">
                        <Edit className="mr-2 h-4 w-4" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem className="text-popover-foreground focus:bg-accent focus:text-accent-foreground">
                        <Copy className="mr-2 h-4 w-4" />
                        Duplicate
                      </DropdownMenuItem>
                      {campaign.status === "scheduled" && (
                        <DropdownMenuItem className="text-popover-foreground focus:bg-accent focus:text-accent-foreground">
                          <Pause className="mr-2 h-4 w-4" />
                          Pause
                        </DropdownMenuItem>
                      )}
                      {campaign.status === "draft" && (
                        <DropdownMenuItem className="text-popover-foreground focus:bg-accent focus:text-accent-foreground">
                          <Play className="mr-2 h-4 w-4" />
                          Send Now
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem className="text-destructive focus:bg-destructive focus:text-destructive-foreground">
                        <Trash2 className="mr-2 h-4 w-4" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="mt-4 flex items-center gap-2">
                  {getStatusBadge(campaign.status)}
                  {campaign.status === "sent" && (
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {campaign.sentAt}
                    </span>
                  )}
                  {campaign.status === "scheduled" && (
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {campaign.scheduledFor}
                    </span>
                  )}
                </div>

                {campaign.status === "sent" && (
                  <div className="mt-4 grid grid-cols-3 gap-4 pt-4 border-t border-border">
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 text-sm font-medium text-card-foreground">
                        <Users className="h-3 w-3 text-muted-foreground" />
                        {campaign.recipients.toLocaleString()}
                      </div>
                      <p className="text-xs text-muted-foreground">Sent</p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 text-sm font-medium text-primary">
                        <Eye className="h-3 w-3" />
                        {((campaign.opened / campaign.recipients) * 100).toFixed(1)}%
                      </div>
                      <p className="text-xs text-muted-foreground">Opened</p>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-1 text-sm font-medium text-chart-2">
                        <MousePointer className="h-3 w-3" />
                        {((campaign.clicked / campaign.recipients) * 100).toFixed(1)}%
                      </div>
                      <p className="text-xs text-muted-foreground">Clicked</p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredCampaigns.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="h-16 w-16 rounded-full bg-secondary flex items-center justify-center mb-4">
              <Mail className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="text-lg font-medium text-foreground">No campaigns found</h3>
            <p className="text-muted-foreground mt-1">
              {searchQuery ? "Try adjusting your search terms" : "Create your first campaign to get started"}
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
