"use client"

import { DashboardHeader } from "@/components/dashboard/header"
import { StatCard } from "@/components/dashboard/stat-card"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts"
import { Mail, Users, Eye, MousePointer, TrendingUp, Send } from "lucide-react"

const overviewData = [
  { date: "Jan 1", sent: 12000, delivered: 11800, opened: 4200, clicked: 890 },
  { date: "Jan 8", sent: 15000, delivered: 14700, opened: 5400, clicked: 1100 },
  { date: "Jan 15", sent: 18000, delivered: 17600, opened: 6800, clicked: 1450 },
  { date: "Jan 22", sent: 14000, delivered: 13700, opened: 5200, clicked: 980 },
  { date: "Jan 29", sent: 22000, delivered: 21500, opened: 8100, clicked: 1720 },
  { date: "Feb 5", sent: 19000, delivered: 18600, opened: 7200, clicked: 1520 },
  { date: "Feb 12", sent: 24000, delivered: 23500, opened: 9100, clicked: 1950 },
]

const deviceData = [
  { name: "Desktop", value: 45, color: "oklch(0.7 0.18 160)" },
  { name: "Mobile", value: 38, color: "oklch(0.65 0.15 220)" },
  { name: "Tablet", value: 17, color: "oklch(0.75 0.15 80)" },
]

const topCampaigns = [
  { name: "Summer Sale Launch", opens: 4250, clicks: 890, rate: 34.0 },
  { name: "Weekly Newsletter #42", opens: 3100, clicks: 456, rate: 37.8 },
  { name: "Product Update v2.0", opens: 2800, clicks: 520, rate: 42.1 },
  { name: "Re-engagement", opens: 1620, clicks: 324, rate: 30.0 },
  { name: "Welcome Series", opens: 1450, clicks: 380, rate: 45.2 },
]

const hourlyData = [
  { hour: "6am", opens: 120 },
  { hour: "8am", opens: 450 },
  { hour: "10am", opens: 820 },
  { hour: "12pm", opens: 680 },
  { hour: "2pm", opens: 590 },
  { hour: "4pm", opens: 720 },
  { hour: "6pm", opens: 850 },
  { hour: "8pm", opens: 540 },
  { hour: "10pm", opens: 280 },
]

export default function AnalyticsPage() {
  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Analytics"
        description="Track your email campaign performance and insights."
      />

      <div className="p-6 space-y-6">
        {/* Stats Overview */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Emails Sent"
            value="142,320"
            change={{ value: "+18.2%", trend: "up" }}
            icon={Send}
            iconColor="text-primary"
          />
          <StatCard
            title="Delivery Rate"
            value="97.8%"
            change={{ value: "+0.5%", trend: "up" }}
            icon={Mail}
            iconColor="text-chart-2"
          />
          <StatCard
            title="Average Open Rate"
            value="34.2%"
            change={{ value: "+2.4%", trend: "up" }}
            icon={Eye}
            iconColor="text-chart-3"
          />
          <StatCard
            title="Average Click Rate"
            value="7.8%"
            change={{ value: "+1.2%", trend: "up" }}
            icon={MousePointer}
            iconColor="text-chart-4"
          />
        </div>

        {/* Main Charts */}
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="bg-secondary">
            <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Overview
            </TabsTrigger>
            <TabsTrigger value="engagement" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Engagement
            </TabsTrigger>
            <TabsTrigger value="growth" className="data-[state=active]:bg-primary data-[state=active]:text-primary-foreground">
              Growth
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-card-foreground">Email Performance Over Time</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={overviewData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorSent" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="oklch(0.65 0.15 220)" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="oklch(0.65 0.15 220)" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="colorOpened" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="oklch(0.7 0.18 160)" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="oklch(0.7 0.18 160)" stopOpacity={0} />
                        </linearGradient>
                        <linearGradient id="colorClicked" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="oklch(0.75 0.15 80)" stopOpacity={0.3} />
                          <stop offset="95%" stopColor="oklch(0.75 0.15 80)" stopOpacity={0} />
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.01 260)" />
                      <XAxis dataKey="date" stroke="oklch(0.65 0 0)" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="oklch(0.65 0 0)" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "oklch(0.16 0.01 260)",
                          border: "1px solid oklch(0.25 0.01 260)",
                          borderRadius: "8px",
                          color: "oklch(0.95 0 0)",
                        }}
                        labelStyle={{ color: "oklch(0.65 0 0)" }}
                      />
                      <Legend
                        wrapperStyle={{ paddingTop: "20px" }}
                        formatter={(value) => <span style={{ color: "oklch(0.95 0 0)" }}>{value}</span>}
                      />
                      <Area type="monotone" dataKey="sent" name="Sent" stroke="oklch(0.65 0.15 220)" fillOpacity={1} fill="url(#colorSent)" strokeWidth={2} />
                      <Area type="monotone" dataKey="opened" name="Opened" stroke="oklch(0.7 0.18 160)" fillOpacity={1} fill="url(#colorOpened)" strokeWidth={2} />
                      <Area type="monotone" dataKey="clicked" name="Clicked" stroke="oklch(0.75 0.15 80)" fillOpacity={1} fill="url(#colorClicked)" strokeWidth={2} />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="engagement" className="mt-6">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Opens by Time of Day</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={hourlyData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.01 260)" vertical={false} />
                        <XAxis dataKey="hour" stroke="oklch(0.65 0 0)" fontSize={12} tickLine={false} axisLine={false} />
                        <YAxis stroke="oklch(0.65 0 0)" fontSize={12} tickLine={false} axisLine={false} />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "oklch(0.16 0.01 260)",
                            border: "1px solid oklch(0.25 0.01 260)",
                            borderRadius: "8px",
                            color: "oklch(0.95 0 0)",
                          }}
                          labelStyle={{ color: "oklch(0.65 0 0)" }}
                        />
                        <Bar dataKey="opens" fill="oklch(0.7 0.18 160)" radius={[4, 4, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-border bg-card">
                <CardHeader>
                  <CardTitle className="text-card-foreground">Opens by Device</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={deviceData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={100}
                          paddingAngle={4}
                          dataKey="value"
                          label={({ name, value }) => `${name}: ${value}%`}
                          labelLine={false}
                        >
                          {deviceData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip
                          contentStyle={{
                            backgroundColor: "oklch(0.16 0.01 260)",
                            border: "1px solid oklch(0.25 0.01 260)",
                            borderRadius: "8px",
                            color: "oklch(0.95 0 0)",
                          }}
                          formatter={(value: number) => [`${value}%`, "Share"]}
                        />
                      </PieChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="growth" className="mt-6">
            <Card className="border-border bg-card">
              <CardHeader>
                <CardTitle className="text-card-foreground">Subscriber Growth</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[400px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart
                      data={[
                        { month: "Jan", subscribers: 18500, growth: 1200 },
                        { month: "Feb", subscribers: 19700, growth: 1200 },
                        { month: "Mar", subscribers: 21200, growth: 1500 },
                        { month: "Apr", subscribers: 22800, growth: 1600 },
                        { month: "May", subscribers: 24100, growth: 1300 },
                        { month: "Jun", subscribers: 24521, growth: 421 },
                      ]}
                      margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.01 260)" />
                      <XAxis dataKey="month" stroke="oklch(0.65 0 0)" fontSize={12} tickLine={false} axisLine={false} />
                      <YAxis stroke="oklch(0.65 0 0)" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "oklch(0.16 0.01 260)",
                          border: "1px solid oklch(0.25 0.01 260)",
                          borderRadius: "8px",
                          color: "oklch(0.95 0 0)",
                        }}
                        labelStyle={{ color: "oklch(0.65 0 0)" }}
                      />
                      <Legend
                        wrapperStyle={{ paddingTop: "20px" }}
                        formatter={(value) => <span style={{ color: "oklch(0.95 0 0)" }}>{value}</span>}
                      />
                      <Line type="monotone" dataKey="subscribers" name="Total Subscribers" stroke="oklch(0.7 0.18 160)" strokeWidth={2} dot={{ fill: "oklch(0.7 0.18 160)", strokeWidth: 2 }} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Top Campaigns Table */}
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-card-foreground flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              Top Performing Campaigns
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topCampaigns.map((campaign, index) => (
                <div
                  key={campaign.name}
                  className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-bold text-primary">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-card-foreground">{campaign.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {campaign.opens.toLocaleString()} opens · {campaign.clicks.toLocaleString()} clicks
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-primary">{campaign.rate}%</p>
                    <p className="text-xs text-muted-foreground">Open Rate</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
