"use client"

import { useState } from "react"
import { DashboardHeader } from "@/components/dashboard/header"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Search, Filter, MoreHorizontal, Mail, Trash2, Edit, Download } from "lucide-react"

const contacts = [
  {
    id: 1,
    name: "Sarah Johnson",
    email: "sarah.johnson@example.com",
    status: "subscribed",
    source: "Website",
    lists: ["Newsletter", "Product Updates"],
    lastActivity: "2 hours ago",
  },
  {
    id: 2,
    name: "Michael Chen",
    email: "m.chen@techcorp.io",
    status: "subscribed",
    source: "Import",
    lists: ["Newsletter"],
    lastActivity: "1 day ago",
  },
  {
    id: 3,
    name: "Emma Wilson",
    email: "emma.w@startup.com",
    status: "unsubscribed",
    source: "API",
    lists: ["Product Updates"],
    lastActivity: "3 days ago",
  },
  {
    id: 4,
    name: "James Brown",
    email: "james.brown@enterprise.net",
    status: "subscribed",
    source: "Website",
    lists: ["Newsletter", "Promotions"],
    lastActivity: "5 hours ago",
  },
  {
    id: 5,
    name: "Lisa Garcia",
    email: "lisa.garcia@company.org",
    status: "bounced",
    source: "Import",
    lists: ["Newsletter"],
    lastActivity: "1 week ago",
  },
  {
    id: 6,
    name: "David Kim",
    email: "d.kim@agency.co",
    status: "subscribed",
    source: "Website",
    lists: ["Newsletter", "Product Updates", "Promotions"],
    lastActivity: "12 hours ago",
  },
  {
    id: 7,
    name: "Amanda Lee",
    email: "amanda.lee@design.studio",
    status: "subscribed",
    source: "API",
    lists: ["Product Updates"],
    lastActivity: "2 days ago",
  },
  {
    id: 8,
    name: "Robert Martinez",
    email: "r.martinez@consulting.biz",
    status: "subscribed",
    source: "Website",
    lists: ["Newsletter"],
    lastActivity: "4 hours ago",
  },
]

function getStatusBadge(status: string) {
  switch (status) {
    case "subscribed":
      return <Badge className="bg-primary/20 text-primary border-0">Subscribed</Badge>
    case "unsubscribed":
      return <Badge variant="secondary" className="bg-muted text-muted-foreground border-0">Unsubscribed</Badge>
    case "bounced":
      return <Badge className="bg-destructive/20 text-destructive border-0">Bounced</Badge>
    default:
      return null
  }
}

export default function ContactsPage() {
  const [selectedContacts, setSelectedContacts] = useState<number[]>([])
  const [searchQuery, setSearchQuery] = useState("")

  const filteredContacts = contacts.filter(
    (contact) =>
      contact.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      contact.email.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const toggleSelectAll = () => {
    if (selectedContacts.length === filteredContacts.length) {
      setSelectedContacts([])
    } else {
      setSelectedContacts(filteredContacts.map((c) => c.id))
    }
  }

  const toggleSelect = (id: number) => {
    setSelectedContacts((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    )
  }

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Contacts"
        description="Manage your email subscribers and contacts."
        action={{
          label: "Add Contact",
          onClick: () => {},
        }}
      />

      <div className="p-6 space-y-6">
        {/* Filters and Search */}
        <Card className="border-border bg-card">
          <CardContent className="p-4">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Search contacts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-9 bg-secondary border-border text-foreground placeholder:text-muted-foreground"
                />
              </div>
              <div className="flex gap-2">
                <Button variant="outline" className="border-border bg-secondary text-foreground hover:bg-muted">
                  <Filter className="mr-2 h-4 w-4" />
                  Filter
                </Button>
                <Button variant="outline" className="border-border bg-secondary text-foreground hover:bg-muted">
                  <Download className="mr-2 h-4 w-4" />
                  Export
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Selected Actions */}
        {selectedContacts.length > 0 && (
          <div className="flex items-center gap-4 p-4 rounded-lg bg-primary/10 border border-primary/20">
            <span className="text-sm text-foreground">
              {selectedContacts.length} contact(s) selected
            </span>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" className="border-primary text-primary hover:bg-primary hover:text-primary-foreground">
                <Mail className="mr-2 h-4 w-4" />
                Send Email
              </Button>
              <Button size="sm" variant="outline" className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground">
                <Trash2 className="mr-2 h-4 w-4" />
                Delete
              </Button>
            </div>
          </div>
        )}

        {/* Contacts Table */}
        <Card className="border-border bg-card">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedContacts.length === filteredContacts.length && filteredContacts.length > 0}
                      onCheckedChange={toggleSelectAll}
                    />
                  </TableHead>
                  <TableHead className="text-muted-foreground">Name</TableHead>
                  <TableHead className="text-muted-foreground">Email</TableHead>
                  <TableHead className="text-muted-foreground">Status</TableHead>
                  <TableHead className="text-muted-foreground hidden md:table-cell">Lists</TableHead>
                  <TableHead className="text-muted-foreground hidden lg:table-cell">Source</TableHead>
                  <TableHead className="text-muted-foreground hidden lg:table-cell">Last Activity</TableHead>
                  <TableHead className="w-12"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredContacts.map((contact) => (
                  <TableRow key={contact.id} className="border-border hover:bg-secondary/50">
                    <TableCell>
                      <Checkbox
                        checked={selectedContacts.includes(contact.id)}
                        onCheckedChange={() => toggleSelect(contact.id)}
                      />
                    </TableCell>
                    <TableCell className="font-medium text-card-foreground">{contact.name}</TableCell>
                    <TableCell className="text-muted-foreground">{contact.email}</TableCell>
                    <TableCell>{getStatusBadge(contact.status)}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      <div className="flex flex-wrap gap-1">
                        {contact.lists.slice(0, 2).map((list) => (
                          <Badge key={list} variant="secondary" className="bg-secondary text-secondary-foreground text-xs">
                            {list}
                          </Badge>
                        ))}
                        {contact.lists.length > 2 && (
                          <Badge variant="secondary" className="bg-secondary text-secondary-foreground text-xs">
                            +{contact.lists.length - 2}
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground hidden lg:table-cell">{contact.source}</TableCell>
                    <TableCell className="text-muted-foreground hidden lg:table-cell">{contact.lastActivity}</TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="bg-popover border-border">
                          <DropdownMenuItem className="text-popover-foreground focus:bg-accent focus:text-accent-foreground">
                            <Edit className="mr-2 h-4 w-4" />
                            Edit
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-popover-foreground focus:bg-accent focus:text-accent-foreground">
                            <Mail className="mr-2 h-4 w-4" />
                            Send Email
                          </DropdownMenuItem>
                          <DropdownMenuItem className="text-destructive focus:bg-destructive focus:text-destructive-foreground">
                            <Trash2 className="mr-2 h-4 w-4" />
                            Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Pagination */}
        <div className="flex items-center justify-between">
          <p className="text-sm text-muted-foreground">
            Showing {filteredContacts.length} of {contacts.length} contacts
          </p>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" disabled className="border-border bg-secondary text-muted-foreground">
              Previous
            </Button>
            <Button variant="outline" size="sm" className="border-border bg-secondary text-foreground hover:bg-muted">
              Next
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
