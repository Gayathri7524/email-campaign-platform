"use client"

import { DashboardHeader } from "@/components/dashboard/header"
import { StatCard } from "@/components/dashboard/stat-card"
import { RecentCampaigns } from "@/components/dashboard/recent-campaigns"
import { EmailPerformanceChart } from "@/components/dashboard/email-performance-chart"
import { SubscriberGrowthChart } from "@/components/dashboard/subscriber-growth-chart"
import { Mail, Users, MousePointer, Eye } from "lucide-react"
import { useRouter } from "next/navigation"

export default function DashboardPage() {
  const router = useRouter()

  return (
    <div className="flex flex-col">
      <DashboardHeader
        title="Dashboard"
        description="Welcome back! Here's an overview of your email campaigns."
        action={{
          label: "New Campaign",
          onClick: () => router.push("/dashboard/campaigns/new"),
        }}
      />

      <div className="p-6 space-y-6">
        {/* Stats Grid */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Total Subscribers"
            value="24,521"
            change={{ value: "+12.5%", trend: "up" }}
            icon={Users}
            iconColor="text-primary"
          />
          <StatCard
            title="Emails Sent"
            value="142.3K"
            change={{ value: "+8.2%", trend: "up" }}
            icon={Mail}
            iconColor="text-chart-2"
          />
          <StatCard
            title="Open Rate"
            value="34.2%"
            change={{ value: "+2.4%", trend: "up" }}
            icon={Eye}
            iconColor="text-chart-3"
          />
          <StatCard
            title="Click Rate"
            value="7.8%"
            change={{ value: "-0.3%", trend: "down" }}
            icon={MousePointer}
            iconColor="text-chart-4"
          />
        </div>

        {/* Charts Row */}
        <div className="grid gap-6 lg:grid-cols-2">
          <EmailPerformanceChart />
          <SubscriberGrowthChart />
        </div>

        {/* Recent Campaigns */}
        <RecentCampaigns />
      </div>
    </div>
  )
}
