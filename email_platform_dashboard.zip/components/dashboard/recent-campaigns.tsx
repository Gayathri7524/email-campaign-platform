"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowRight, Mail, Eye, MousePointer } from "lucide-react"
import Link from "next/link"

const recentCampaigns = [
  {
    id: 1,
    name: "Summer Sale Launch",
    status: "sent",
    sent: 12500,
    opened: 4250,
    clicked: 890,
    date: "2 hours ago",
  },
  {
    id: 2,
    name: "Weekly Newsletter #42",
    status: "sent",
    sent: 8200,
    opened: 3100,
    clicked: 456,
    date: "1 day ago",
  },
  {
    id: 3,
    name: "Product Update v2.0",
    status: "draft",
    sent: 0,
    opened: 0,
    clicked: 0,
    date: "2 days ago",
  },
  {
    id: 4,
    name: "Welcome Series - Day 1",
    status: "scheduled",
    sent: 0,
    opened: 0,
    clicked: 0,
    date: "Tomorrow",
  },
]

function getStatusBadge(status: string) {
  switch (status) {
    case "sent":
      return <Badge className="bg-primary/20 text-primary border-0">Sent</Badge>
    case "draft":
      return <Badge variant="secondary" className="bg-muted text-muted-foreground border-0">Draft</Badge>
    case "scheduled":
      return <Badge className="bg-chart-3/20 text-chart-3 border-0">Scheduled</Badge>
    default:
      return null
  }
}

export function RecentCampaigns() {
  return (
    <Card className="border-border bg-card">
      <CardHeader className="flex flex-row items-center justify-between">
        <CardTitle className="text-card-foreground">Recent Campaigns</CardTitle>
        <Link href="/dashboard/campaigns">
          <Button variant="ghost" className="text-muted-foreground hover:text-foreground">
            View all
            <ArrowRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {recentCampaigns.map((campaign) => (
            <div
              key={campaign.id}
              className="flex items-center justify-between p-4 rounded-lg bg-secondary/50 hover:bg-secondary transition-colors"
            >
              <div className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Mail className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="font-medium text-card-foreground">{campaign.name}</p>
                  <p className="text-sm text-muted-foreground">{campaign.date}</p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                {campaign.status === "sent" && (
                  <>
                    <div className="text-right hidden sm:block">
                      <p className="text-sm text-muted-foreground">Opens</p>
                      <p className="font-medium text-card-foreground flex items-center gap-1">
                        <Eye className="h-3 w-3 text-primary" />
                        {((campaign.opened / campaign.sent) * 100).toFixed(1)}%
                      </p>
                    </div>
                    <div className="text-right hidden sm:block">
                      <p className="text-sm text-muted-foreground">Clicks</p>
                      <p className="font-medium text-card-foreground flex items-center gap-1">
                        <MousePointer className="h-3 w-3 text-chart-2" />
                        {((campaign.clicked / campaign.sent) * 100).toFixed(1)}%
                      </p>
                    </div>
                  </>
                )}
                {getStatusBadge(campaign.status)}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}
