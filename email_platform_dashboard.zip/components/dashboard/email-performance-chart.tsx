"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Legend,
} from "recharts"

const data = [
  { month: "Jan", opens: 4200, clicks: 1200 },
  { month: "Feb", opens: 5100, clicks: 1450 },
  { month: "Mar", opens: 4800, clicks: 1380 },
  { month: "Apr", opens: 6200, clicks: 1890 },
  { month: "May", opens: 7400, clicks: 2100 },
  { month: "Jun", opens: 8100, clicks: 2450 },
  { month: "Jul", opens: 7800, clicks: 2380 },
]

export function EmailPerformanceChart() {
  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="text-card-foreground">Email Performance</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart
              data={data}
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <defs>
                <linearGradient id="colorOpens" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.7 0.18 160)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.7 0.18 160)" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorClicks" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="oklch(0.65 0.15 220)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="oklch(0.65 0.15 220)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.01 260)" />
              <XAxis
                dataKey="month"
                stroke="oklch(0.65 0 0)"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="oklch(0.65 0 0)"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${(value / 1000).toFixed(0)}k`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "oklch(0.16 0.01 260)",
                  border: "1px solid oklch(0.25 0.01 260)",
                  borderRadius: "8px",
                  color: "oklch(0.95 0 0)",
                }}
                labelStyle={{ color: "oklch(0.65 0 0)" }}
              />
              <Legend
                wrapperStyle={{ paddingTop: "20px" }}
                formatter={(value) => (
                  <span style={{ color: "oklch(0.95 0 0)" }}>{value}</span>
                )}
              />
              <Area
                type="monotone"
                dataKey="opens"
                name="Opens"
                stroke="oklch(0.7 0.18 160)"
                fillOpacity={1}
                fill="url(#colorOpens)"
                strokeWidth={2}
              />
              <Area
                type="monotone"
                dataKey="clicks"
                name="Clicks"
                stroke="oklch(0.65 0.15 220)"
                fillOpacity={1}
                fill="url(#colorClicks)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
