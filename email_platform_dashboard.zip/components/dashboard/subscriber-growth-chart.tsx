"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts"

const data = [
  { month: "Jan", subscribers: 1200, color: "oklch(0.7 0.18 160)" },
  { month: "Feb", subscribers: 1890, color: "oklch(0.7 0.18 160)" },
  { month: "Mar", subscribers: 2100, color: "oklch(0.7 0.18 160)" },
  { month: "Apr", subscribers: 2450, color: "oklch(0.7 0.18 160)" },
  { month: "May", subscribers: 3200, color: "oklch(0.7 0.18 160)" },
  { month: "Jun", subscribers: 3800, color: "oklch(0.7 0.18 160)" },
  { month: "Jul", subscribers: 4100, color: "oklch(0.7 0.18 160)" },
]

export function SubscriberGrowthChart() {
  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="text-card-foreground">Subscriber Growth</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-[300px]">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.25 0.01 260)" vertical={false} />
              <XAxis
                dataKey="month"
                stroke="oklch(0.65 0 0)"
                fontSize={12}
                tickLine={false}
                axisLine={false}
              />
              <YAxis
                stroke="oklch(0.65 0 0)"
                fontSize={12}
                tickLine={false}
                axisLine={false}
                tickFormatter={(value) => `${(value / 1000).toFixed(1)}k`}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "oklch(0.16 0.01 260)",
                  border: "1px solid oklch(0.25 0.01 260)",
                  borderRadius: "8px",
                  color: "oklch(0.95 0 0)",
                }}
                labelStyle={{ color: "oklch(0.65 0 0)" }}
                formatter={(value: number) => [`${value.toLocaleString()} new subscribers`, "Growth"]}
              />
              <Bar dataKey="subscribers" radius={[4, 4, 0, 0]}>
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}
